const discord = require("discord.js");
const { GoogleGenerativeAI, TaskType } = require("@google/generative-ai");

const MODEL = "gemini-pro";
const API_KEY =
  process.env.API_KEY ?? "AIzaSyC-oCIfy9DDnjYugcQOybroGHv78-rMmSY";
const BOT_TOKEN =
  process.env.BOT_TOKEN ??
  "MTI3NTAzNDcwNjAwMTI2ODc0Ng.G539vk.L-m63YIedbOMHpRuUTIl7PNGwuEd3LHRxLlb9U";
const CHANNEL_ID = process.env.CHANNEL_ID ?? "1265113143953330226";
const ai = new GoogleGenerativeAI(API_KEY);
const model = ai.getGenerativeModel({ model: MODEL });

const client = new discord.Client({
  intents: Object.keys(discord.GatewayIntentBits),
});

client.on("ready", () => {
  console.log("Rem đã sẵn sàng phục vụ chủ nhân");
});

client.login(BOT_TOKEN);

client.on("messageCreate", async (message) => {
  try {

    if (message.author.bot) return;
    if (message.channel.id !== CHANNEL_ID) return;
    if (
      message.content.trim().toLowerCase().includes("ai là chủ nhân của rem ?")
    ) {
      const response =
        "Mị là Rem, một AI được tạo ra bởi Ember để phục vụ mọi người.";
      await message.reply({
        content: response.trim(),
      });
      return;
    }
    if (message.content.trim().toLowerCase().includes("mandu là ai ?")) {
      const response =
        "Mandu là một cái bánh màn thầu tham lam háu thắng và tên thật là Jun Lam";
      await message.reply({
        content: response.trim(),
      });
      return;
    }
    if (message.content.trim().toLowerCase().includes("bom là ai ?")) {
      const response = "B0nk B0nk Bakudan!!!";
      await message.reply({
        content: response.trim(),
      });
      return;
    }
    if (message.content.trim().toLowerCase().includes("pat rem")) {
      const response = "https://i.imgur.com/1dYghLr.gif";
      await message.reply({
        content: response.trim(),
      });
      return;
    }
    if (message.content.trim().toLowerCase().includes("mandu là số 1")) {
      const response = "Rem cũng đồng ý nà, nhưng mà là số 1 từ dưới đếm lên á!";
      await message.reply({
        content: response.trim(),
      });
      return;
    }
    if (
      message.content.trim().toLowerCase().includes("rem hãy giúp ember wa nào")
    ) {
      const response = "$wa";
      for (let i = 0; i < 18; i++) {
        await new Promise((resolve) => setTimeout(resolve, 2000)); 
        await message.reply({
          content: response.trim(),
        });
      }
      await message.reply({
        content: "Rem đã xong việc òi nè Ember",
      });
      return;
    }
    if (message.content.startsWith("!!")) {
      await message.channel.sendTyping();
      const { response } = await model.generateContent(
        message.cleanContent.substring(3),
      );
      await message.reply({
        content: response.text().trim(),
      });
    } else return;
  } catch (e) {
    console.error(e);
  }
});
